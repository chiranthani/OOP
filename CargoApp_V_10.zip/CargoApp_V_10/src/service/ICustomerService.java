package service;

import model.Register;

public interface ICustomerService {

	public void customerRegister(Register register);
	
	public boolean loginCheck(String uname,String pass,String utype);
	
	public String GetID(String uname,String pass,String utype);
	
}
