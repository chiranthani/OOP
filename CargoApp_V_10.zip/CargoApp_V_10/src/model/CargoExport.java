package model;

public class CargoExport extends Export{
	
	
	private String noOfContainers;
	private String netWeight;
	private String dimensions;
	
	public CargoExport() {
		super();

	}

	public String getNoOfContainers() {
		return noOfContainers;
	}

	public void setNoOfContainers(String noOfContainers) {
		this.noOfContainers = noOfContainers;
	}

	public String getNetWeight() {
		return netWeight;
	}

	public void setNetWeight(String netWeight) {
		this.netWeight = netWeight;
	}

	public String getDimensions() {
		return dimensions;
	}

	public void setDimensions(String dimensions) {
		this.dimensions = dimensions;
	}

}
