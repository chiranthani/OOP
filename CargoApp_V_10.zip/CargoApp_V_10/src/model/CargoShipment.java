package model;

public class CargoShipment extends Shipment {

	private String shipmentID;
	

	public CargoShipment() {
		super();
		
	}
	
	public String getShipmentID() {
		return shipmentID;
	}

	public void setShipmentID(String shipmentID) {
		this.shipmentID = shipmentID;
	}


	
}
