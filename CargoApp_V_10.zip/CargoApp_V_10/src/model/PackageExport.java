package model;

public class PackageExport extends Export{
		
	private String weightOfProduct;
	
	
	public PackageExport() {
		super();
		
	}

	public String getWeightOfProduct() {
		return weightOfProduct;
	}

	public void setWeightOfProduct(String weightOfProduct) {
		this.weightOfProduct = weightOfProduct;
	}	
	
}
