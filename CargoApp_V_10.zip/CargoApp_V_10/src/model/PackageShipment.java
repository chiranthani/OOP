package model;

public class PackageShipment extends Shipment {

	private String PshipmentID;

	public PackageShipment() {
		super();
		
	}

	public String getPshipmentID() {
		return PshipmentID;
	}
	public void setPshipmentID(String pshipmentID) {
		PshipmentID = pshipmentID;
	}
	


	
}
